%% Dobieranie_nastaw_regulatora
% Autor: Adam Miarka, Damian Kad�uczka
% Data: 17.03.2016r.
%%

%% Dane wej�ciowe


